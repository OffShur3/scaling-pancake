<?php

/*
Plugin Name: PWNING SHELL
Plugin URI: http://ddlr.org
Description: Una shell en php pal wp
Version: 1.0
Author: DDLR
Author URI: http://ddlr.org
License: GPL2
*/

?>
